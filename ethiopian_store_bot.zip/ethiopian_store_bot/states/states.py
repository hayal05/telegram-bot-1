"""
states/states.py — All FSM state groups for the bot.
"""
from aiogram.fsm.state import State, StatesGroup


class PurchaseFlow(StatesGroup):
    """User-facing purchase journey."""
    choosing_category  = State()   # user picks book/movie/music
    choosing_product   = State()   # user picks a specific item
    choosing_payment   = State()   # user picks CBE / BoA / Telebirr
    awaiting_proof     = State()   # waiting for txn reference or screenshot
    awaiting_txn_ref   = State()   # optional follow-up: manual ref number


class AdminSettingsFlow(StatesGroup):
    """Admin: edit system payment configuration."""
    main_menu          = State()   # shows the settings overview
    editing_telebirr   = State()   # waiting for new Telebirr number
    editing_cbe        = State()   # waiting for new CBE account
    editing_boa        = State()   # waiting for new BoA account


class AdminProductFlow(StatesGroup):
    """Admin: add a new product."""
    title       = State()
    category    = State()
    price       = State()
    drive_link  = State()
