"""
database.py — Async SQLite database layer using aiosqlite.
All schema creation, CRUD helpers, and SystemSettings management live here.
"""
import asyncio
import aiosqlite
from datetime import datetime
from pathlib import Path

DB_PATH = Path("store.db")


# ─────────────────────────────────────────────
#  Schema
# ─────────────────────────────────────────────
SCHEMA_SQL = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS products (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT    NOT NULL,
    category    TEXT    NOT NULL CHECK(category IN ('book','movie','music')),
    price       REAL    NOT NULL,
    drive_link  TEXT    NOT NULL,
    is_active   INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS orders (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL,
    product_id   INTEGER NOT NULL REFERENCES products(id),
    status       TEXT    NOT NULL DEFAULT 'pending'
                         CHECK(status IN ('pending','verified','rejected')),
    special_code TEXT    NOT NULL UNIQUE,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS transactions (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id              INTEGER NOT NULL REFERENCES orders(id),
    payment_method        TEXT    NOT NULL CHECK(payment_method IN ('cbe','boa','telebirr')),
    transaction_reference TEXT    UNIQUE,          -- UNIQUE: prevents double-submission
    payee_name            TEXT,
    phone_number          TEXT,
    amount                REAL,
    screenshot_path       TEXT,
    verified_at           TEXT,
    created_at            TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS system_settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Seed default system settings (ignored if rows already exist)
INSERT OR IGNORE INTO system_settings (key, value) VALUES
    ('telebirr_phone',  '0900000000'),
    ('cbe_account',     '1000000000000'),
    ('boa_account',     '2000000000000'),
    ('admin_ids',       ''),          -- comma-separated Telegram user IDs
    ('bot_username',    'MyStoreBot');
"""


async def init_db() -> None:
    """Create tables and seed default settings on first run."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(SCHEMA_SQL)
        await db.commit()


# ─────────────────────────────────────────────
#  SystemSettings helpers
# ─────────────────────────────────────────────
async def get_setting(key: str) -> str | None:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT value FROM system_settings WHERE key = ?", (key,)
        ) as cur:
            row = await cur.fetchone()
            return row[0] if row else None


async def set_setting(key: str, value: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO system_settings (key, value) VALUES (?, ?)"
            "  ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )
        await db.commit()


async def get_all_settings() -> dict[str, str]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT key, value FROM system_settings") as cur:
            rows = await cur.fetchall()
            return {r["key"]: r["value"] for r in rows}


# ─────────────────────────────────────────────
#  Product helpers
# ─────────────────────────────────────────────
async def get_products(category: str | None = None) -> list[dict]:
    query = "SELECT * FROM products WHERE is_active = 1"
    params: tuple = ()
    if category:
        query += " AND category = ?"
        params = (category,)
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(query, params) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_product(product_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM products WHERE id = ?", (product_id,)
        ) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


# ─────────────────────────────────────────────
#  Order helpers
# ─────────────────────────────────────────────
async def create_order(user_id: int, product_id: int, special_code: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO orders (user_id, product_id, special_code) VALUES (?, ?, ?)",
            (user_id, product_id, special_code),
        )
        await db.commit()
        return cur.lastrowid  # type: ignore[return-value]


async def get_order(order_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """SELECT o.*, p.title, p.price, p.drive_link
               FROM orders o JOIN products p ON o.product_id = p.id
               WHERE o.id = ?""",
            (order_id,),
        ) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def update_order_status(order_id: int, status: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE orders SET status = ? WHERE id = ?", (status, order_id)
        )
        await db.commit()


# ─────────────────────────────────────────────
#  Transaction helpers
# ─────────────────────────────────────────────
async def create_transaction(
    order_id: int,
    payment_method: str,
    transaction_reference: str | None = None,
    payee_name: str | None = None,
    phone_number: str | None = None,
    amount: float | None = None,
    screenshot_path: str | None = None,
) -> int | None:
    """Returns new transaction id, or None on duplicate reference."""
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            cur = await db.execute(
                """INSERT INTO transactions
                   (order_id, payment_method, transaction_reference,
                    payee_name, phone_number, amount, screenshot_path)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    order_id, payment_method, transaction_reference,
                    payee_name, phone_number, amount, screenshot_path,
                ),
            )
            await db.commit()
            return cur.lastrowid  # type: ignore[return-value]
        except aiosqlite.IntegrityError:
            return None  # duplicate transaction_reference


async def get_pending_transactions() -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """SELECT t.*, o.user_id, o.special_code, o.product_id,
                      p.title AS product_title, p.drive_link
               FROM transactions t
               JOIN orders o ON t.order_id = o.id
               JOIN products p ON o.product_id = p.id
               WHERE o.status = 'pending'
               ORDER BY t.created_at ASC"""
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_transaction(txn_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """SELECT t.*, o.user_id, o.special_code, o.product_id,
                      p.title AS product_title, p.drive_link
               FROM transactions t
               JOIN orders o ON t.order_id = o.id
               JOIN products p ON o.product_id = p.id
               WHERE t.id = ?""",
            (txn_id,),
        ) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def verify_transaction(txn_id: int) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE transactions SET verified_at = ? WHERE id = ?",
            (datetime.utcnow().isoformat(), txn_id),
        )
        await db.commit()
