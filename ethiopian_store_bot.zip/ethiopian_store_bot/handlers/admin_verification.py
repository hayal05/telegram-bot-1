"""
handlers/admin_verification.py — Admin transaction review queue.
Admins can view pending payments, inspect details/screenshots, and
approve (→ sends Google Drive link) or reject.
"""
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, FSInputFile

from database import (
    get_pending_transactions, get_transaction,
    update_order_status, verify_transaction,
)
from keyboards.keyboards import kb_admin_main, kb_pending_list, kb_verify_reject
from utils.helpers import admin_required, admin_callback_required, PAYMENT_METHOD_LABELS

router = Router()


# ─────────────────────────────────────────────
#  /admin — main admin panel entry
# ─────────────────────────────────────────────
@router.message(Command("admin"))
@admin_required
async def cmd_admin(message: Message):
    await message.answer(
        "🔧 *Admin Control Panel*\n\nWhat would you like to do?",
        reply_markup=kb_admin_main(),
        parse_mode="Markdown",
    )


@router.callback_query(F.data == "admin:main")
@admin_callback_required
async def cb_admin_main(callback: CallbackQuery):
    await callback.message.edit_text(  # type: ignore[union-attr]
        "🔧 *Admin Control Panel*\n\nWhat would you like to do?",
        reply_markup=kb_admin_main(),
        parse_mode="Markdown",
    )
    await callback.answer()


# ─────────────────────────────────────────────
#  Pending transaction queue
# ─────────────────────────────────────────────
@router.callback_query(F.data == "admin:queue")
@admin_callback_required
async def cb_admin_queue(callback: CallbackQuery):
    pending = await get_pending_transactions()

    if not pending:
        await callback.message.edit_text(  # type: ignore[union-attr]
            "✅ No pending transactions at the moment.",
            reply_markup=kb_admin_main(),
        )
        await callback.answer()
        return

    await callback.message.edit_text(  # type: ignore[union-attr]
        f"📋 *Pending Transactions* ({len(pending)} total)\n\nSelect one to review:",
        reply_markup=kb_pending_list(pending),
        parse_mode="Markdown",
    )
    await callback.answer()


# ─────────────────────────────────────────────
#  Review a single transaction
# ─────────────────────────────────────────────
@router.callback_query(F.data.startswith("admin_review:"))
@admin_callback_required
async def cb_admin_review(callback: CallbackQuery, bot: Bot):
    txn_id = int(callback.data.split(":")[1])  # type: ignore[union-attr]
    txn    = await get_transaction(txn_id)

    if not txn:
        await callback.answer("Transaction not found.", show_alert=True)
        return

    method_label = PAYMENT_METHOD_LABELS.get(txn["payment_method"], txn["payment_method"])
    detail_text  = (
        f"🔍 *Transaction #{txn_id}*\n\n"
        f"👤 User ID: `{txn['user_id']}`\n"
        f"📦 Product: *{txn['product_title']}*\n"
        f"💳 Method: {method_label}\n"
        f"🔑 Special Code: `{txn['special_code']}`\n"
        f"📝 Reference: `{txn.get('transaction_reference') or '—'}`\n"
        f"💰 Amount: {txn.get('amount') or '—'} ETB\n"
        f"🕐 Submitted: {txn['created_at']}\n"
    )

    # If there is a screenshot, send it as a separate message first
    screenshot = txn.get("screenshot_path")
    if screenshot:
        try:
            await bot.send_photo(
                chat_id=callback.from_user.id,  # type: ignore[union-attr]
                photo=FSInputFile(screenshot),
                caption=f"📸 Screenshot for Transaction #{txn_id}",
            )
        except Exception:
            detail_text += "\n⚠️ Screenshot could not be loaded."

    await callback.message.answer(  # type: ignore[union-attr]
        detail_text,
        reply_markup=kb_verify_reject(txn_id),
        parse_mode="Markdown",
    )
    await callback.answer()


# ─────────────────────────────────────────────
#  Approve a transaction → send drive link
# ─────────────────────────────────────────────
@router.callback_query(F.data.startswith("admin_approve:"))
@admin_callback_required
async def cb_admin_approve(callback: CallbackQuery, bot: Bot):
    txn_id = int(callback.data.split(":")[1])  # type: ignore[union-attr]
    txn    = await get_transaction(txn_id)

    if not txn:
        await callback.answer("Transaction not found.", show_alert=True)
        return

    # Update DB
    await verify_transaction(txn_id)
    await update_order_status(txn["order_id"], "verified")

    # Deliver product to buyer
    buyer_id   = txn["user_id"]
    drive_link = txn["drive_link"]
    product    = txn["product_title"]

    try:
        await bot.send_message(
            chat_id=buyer_id,
            text=(
                f"🎉 *Your payment has been verified!*\n\n"
                f"Thank you for purchasing *{product}*.\n\n"
                f"Here is your download link:\n{drive_link}\n\n"
                f"Enjoy! 🇪🇹"
            ),
            parse_mode="Markdown",
        )
        buyer_notified = True
    except Exception:
        buyer_notified = False

    status_note = "✅ Buyer notified." if buyer_notified else "⚠️ Could not reach buyer (they may have blocked the bot)."

    await callback.message.edit_reply_markup(reply_markup=None)  # type: ignore[union-attr]
    await callback.message.answer(  # type: ignore[union-attr]
        f"✅ Transaction #{txn_id} approved.\n{status_note}",
        reply_markup=kb_admin_main(),
    )
    await callback.answer("Approved!", show_alert=False)


# ─────────────────────────────────────────────
#  Reject a transaction
# ─────────────────────────────────────────────
@router.callback_query(F.data.startswith("admin_reject:"))
@admin_callback_required
async def cb_admin_reject(callback: CallbackQuery, bot: Bot):
    txn_id = int(callback.data.split(":")[1])  # type: ignore[union-attr]
    txn    = await get_transaction(txn_id)

    if not txn:
        await callback.answer("Transaction not found.", show_alert=True)
        return

    await update_order_status(txn["order_id"], "rejected")

    try:
        await bot.send_message(
            chat_id=txn["user_id"],
            text=(
                "❌ *Your payment could not be verified.*\n\n"
                "Your transaction has been rejected. This may be because:\n"
                "• The special code was missing from the remark field\n"
                "• The reference number was incorrect\n"
                "• The amount did not match\n\n"
                "Please contact support or try purchasing again."
            ),
            parse_mode="Markdown",
        )
    except Exception:
        pass

    await callback.message.edit_reply_markup(reply_markup=None)  # type: ignore[union-attr]
    await callback.message.answer(  # type: ignore[union-attr]
        f"❌ Transaction #{txn_id} rejected. Buyer has been notified.",
        reply_markup=kb_admin_main(),
    )
    await callback.answer("Rejected.", show_alert=False)
