"""
handlers/purchase.py — User purchase journey:
  category → product → payment method → proof submission.
"""
import os
from pathlib import Path

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery

from database import (
    get_products, get_product, create_order, create_transaction, get_setting
)
from keyboards.keyboards import (
    kb_categories, kb_products, kb_payment_methods, kb_cancel_purchase
)
from states.states import PurchaseFlow
from utils.helpers import generate_special_code, fmt_product, fmt_payment_instruction

router = Router()

SCREENSHOTS_DIR = Path("screenshots")
SCREENSHOTS_DIR.mkdir(exist_ok=True)

# ─────────────────────────────────────────────
#  /start — welcome + category selection
# ─────────────────────────────────────────────
@router.message(Command("start"))
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "🇪🇹 *Welcome to the Ethiopian Digital Store!*\n\n"
        "Browse our collection of books, movies, and music.\n"
        "Choose a category to get started:",
        reply_markup=kb_categories(),
        parse_mode="Markdown",
    )
    await state.set_state(PurchaseFlow.choosing_category)


# ─────────────────────────────────────────────
#  Category selection
# ─────────────────────────────────────────────
@router.callback_query(PurchaseFlow.choosing_category, F.data.startswith("cat:"))
async def cb_category_selected(callback: CallbackQuery, state: FSMContext):
    category = callback.data.split(":")[1]  # type: ignore[union-attr]
    products = await get_products(category)

    if not products:
        await callback.answer("No products available in this category right now.", show_alert=True)
        return

    await state.update_data(category=category)
    await state.set_state(PurchaseFlow.choosing_product)

    await callback.message.edit_text(  # type: ignore[union-attr]
        f"Select a product:",
        reply_markup=kb_products(products),
    )
    await callback.answer()


@router.callback_query(F.data == "back:categories")
async def cb_back_to_categories(callback: CallbackQuery, state: FSMContext):
    await state.set_state(PurchaseFlow.choosing_category)
    await callback.message.edit_text(  # type: ignore[union-attr]
        "Choose a category:",
        reply_markup=kb_categories(),
    )
    await callback.answer()


# ─────────────────────────────────────────────
#  Product selection
# ─────────────────────────────────────────────
@router.callback_query(PurchaseFlow.choosing_product, F.data.startswith("product:"))
async def cb_product_selected(callback: CallbackQuery, state: FSMContext):
    product_id = int(callback.data.split(":")[1])  # type: ignore[union-attr]
    product = await get_product(product_id)

    if not product:
        await callback.answer("Product not found.", show_alert=True)
        return

    await state.update_data(product_id=product_id)
    await state.set_state(PurchaseFlow.choosing_payment)

    await callback.message.edit_text(  # type: ignore[union-attr]
        f"{fmt_product(product)}\n\nChoose your payment method:",
        reply_markup=kb_payment_methods(),
        parse_mode="Markdown",
    )
    await callback.answer()


@router.callback_query(F.data == "back:products")
async def cb_back_to_products(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    category = data.get("category", "book")
    products = await get_products(category)
    await state.set_state(PurchaseFlow.choosing_product)
    await callback.message.edit_text(  # type: ignore[union-attr]
        "Select a product:",
        reply_markup=kb_products(products),
    )
    await callback.answer()


# ─────────────────────────────────────────────
#  Payment method → generate special code → send instructions
# ─────────────────────────────────────────────
PAYMENT_SETTING_KEYS = {
    "cbe":      ("cbe_account",    "CBE"),
    "boa":      ("boa_account",    "BOA"),
    "telebirr": ("telebirr_phone", "TLB"),
}

@router.callback_query(PurchaseFlow.choosing_payment, F.data.startswith("pay:"))
async def cb_payment_selected(callback: CallbackQuery, state: FSMContext):
    method = callback.data.split(":")[1]  # type: ignore[union-attr]
    data   = await state.get_data()
    product = await get_product(data["product_id"])

    if not product:
        await callback.answer("Product no longer available.", show_alert=True)
        return

    setting_key, code_prefix = PAYMENT_SETTING_KEYS[method]
    account = await get_setting(setting_key)

    if not account:
        await callback.answer(
            "⚠️ Payment details not configured. Please contact support.",
            show_alert=True,
        )
        return

    special_code = generate_special_code(code_prefix)
    order_id     = await create_order(
        user_id=callback.from_user.id,  # type: ignore[union-attr]
        product_id=product["id"],
        special_code=special_code,
    )

    await state.update_data(
        method=method,
        order_id=order_id,
        special_code=special_code,
    )
    await state.set_state(PurchaseFlow.awaiting_proof)

    instruction = fmt_payment_instruction(
        method=method,
        account=account,
        amount=product["price"],
        special_code=special_code,
    )

    await callback.message.edit_text(  # type: ignore[union-attr]
        instruction,
        reply_markup=kb_cancel_purchase(),
        parse_mode="Markdown",
    )
    await callback.answer()


# ─────────────────────────────────────────────
#  Proof submission: text (reference number)
# ─────────────────────────────────────────────
@router.message(PurchaseFlow.awaiting_proof, F.text)
async def msg_txn_reference_received(message: Message, state: FSMContext):
    ref = message.text.strip()  # type: ignore[union-attr]
    data = await state.get_data()

    txn_id = await create_transaction(
        order_id=data["order_id"],
        payment_method=data["method"],
        transaction_reference=ref,
    )

    if txn_id is None:
        await message.answer(
            "⚠️ This transaction reference has already been submitted. "
            "If you believe this is an error, please contact support."
        )
        return

    await state.clear()
    await message.answer(
        "✅ *Thank you!* Your transaction reference has been received.\n\n"
        f"Reference: `{ref}`\n\n"
        "An admin will verify your payment and send your download link shortly. "
        "Please be patient!",
        parse_mode="Markdown",
    )


# ─────────────────────────────────────────────
#  Proof submission: photo (screenshot)
# ─────────────────────────────────────────────
@router.message(PurchaseFlow.awaiting_proof, F.photo)
async def msg_screenshot_received(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()

    # Download the highest-resolution photo
    photo   = message.photo[-1]  # type: ignore[index]
    file_id = photo.file_id
    ext_path = SCREENSHOTS_DIR / f"order_{data['order_id']}_{file_id[:8]}.jpg"

    file = await bot.get_file(file_id)
    await bot.download_file(file.file_path, ext_path)  # type: ignore[arg-type]

    txn_id = await create_transaction(
        order_id=data["order_id"],
        payment_method=data["method"],
        screenshot_path=str(ext_path),
    )

    if txn_id is None:
        await message.answer("⚠️ Your screenshot could not be saved. Please try again.")
        return

    await state.clear()
    await message.answer(
        "📸 *Screenshot received!*\n\n"
        "An admin will verify your payment and send your download link shortly.",
        parse_mode="Markdown",
    )


# ─────────────────────────────────────────────
#  Cancel order
# ─────────────────────────────────────────────
@router.callback_query(F.data == "purchase:cancel")
async def cb_cancel_purchase(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(  # type: ignore[union-attr]
        "❌ Order cancelled. Use /start to begin again."
    )
    await callback.answer()
