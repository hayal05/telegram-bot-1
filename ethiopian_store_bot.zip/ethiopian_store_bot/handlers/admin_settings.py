"""
handlers/admin_settings.py — FSM-driven admin panel for editing:
  • Telebirr merchant/phone number
  • CBE account number
  • BoA account number

Changes write to system_settings instantly, so all future payment
instructions shown to users will use the updated values.
"""
import re

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from database import get_all_settings, set_setting
from keyboards.keyboards import kb_settings_menu, kb_back_to_settings, kb_admin_main
from states.states import AdminSettingsFlow
from utils.helpers import admin_callback_required, admin_required

router = Router()


# ─── Validation helpers ─────────────────────────────────────────────────────
_PHONE_RE   = re.compile(r"^(09|07|\+2519|\+2517)\d{8}$")  # Ethiopian numbers
_ACCOUNT_RE = re.compile(r"^\d{10,16}$")                    # 10-16 digit account


def _valid_phone(value: str) -> bool:
    return bool(_PHONE_RE.match(value.strip()))


def _valid_account(value: str) -> bool:
    return bool(_ACCOUNT_RE.match(value.strip()))


# ─── Settings menu ───────────────────────────────────────────────────────────
@router.callback_query(F.data == "admin:settings")
@admin_callback_required
async def cb_settings_menu(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    settings = await get_all_settings()

    await callback.message.edit_text(  # type: ignore[union-attr]
        "⚙️ *Payment Settings*\n\n"
        "Tap a row to update that value. Changes take effect immediately.",
        reply_markup=kb_settings_menu(settings),
        parse_mode="Markdown",
    )
    await state.set_state(AdminSettingsFlow.main_menu)
    await callback.answer()


# ─── Edit Telebirr ───────────────────────────────────────────────────────────
@router.callback_query(AdminSettingsFlow.main_menu, F.data == "settings:edit_telebirr")
@admin_callback_required
async def cb_edit_telebirr(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminSettingsFlow.editing_telebirr)
    await callback.message.edit_text(  # type: ignore[union-attr]
        "📱 *Update Telebirr Number*\n\n"
        "Enter the new Telebirr merchant/phone number.\n"
        "Format: `0911234567` or `+251911234567`",
        reply_markup=kb_back_to_settings(),
        parse_mode="Markdown",
    )
    await callback.answer()


@router.message(AdminSettingsFlow.editing_telebirr)
@admin_required
async def msg_telebirr_input(message: Message, state: FSMContext):
    value = (message.text or "").strip()

    if not _valid_phone(value):
        await message.answer(
            "⚠️ Invalid Ethiopian phone number. "
            "Must start with 09, 07, +2519, or +2517 and be 10 digits.\n\n"
            "Try again:",
            reply_markup=kb_back_to_settings(),
        )
        return

    await set_setting("telebirr_phone", value)
    await state.clear()

    settings = await get_all_settings()
    await message.answer(
        f"✅ Telebirr number updated to `{value}`.",
        parse_mode="Markdown",
    )
    await message.answer(
        "⚙️ *Payment Settings*",
        reply_markup=kb_settings_menu(settings),
        parse_mode="Markdown",
    )
    await state.set_state(AdminSettingsFlow.main_menu)


# ─── Edit CBE ────────────────────────────────────────────────────────────────
@router.callback_query(AdminSettingsFlow.main_menu, F.data == "settings:edit_cbe")
@admin_callback_required
async def cb_edit_cbe(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminSettingsFlow.editing_cbe)
    await callback.message.edit_text(  # type: ignore[union-attr]
        "🏦 *Update CBE Account Number*\n\n"
        "Enter the new CBE account number (10–16 digits):",
        reply_markup=kb_back_to_settings(),
        parse_mode="Markdown",
    )
    await callback.answer()


@router.message(AdminSettingsFlow.editing_cbe)
@admin_required
async def msg_cbe_input(message: Message, state: FSMContext):
    value = (message.text or "").strip()

    if not _valid_account(value):
        await message.answer(
            "⚠️ Invalid account number. Must be 10–16 digits with no spaces.\n\nTry again:",
            reply_markup=kb_back_to_settings(),
        )
        return

    await set_setting("cbe_account", value)
    await state.clear()

    settings = await get_all_settings()
    await message.answer(f"✅ CBE account updated to `{value}`.", parse_mode="Markdown")
    await message.answer(
        "⚙️ *Payment Settings*",
        reply_markup=kb_settings_menu(settings),
        parse_mode="Markdown",
    )
    await state.set_state(AdminSettingsFlow.main_menu)


# ─── Edit BoA ────────────────────────────────────────────────────────────────
@router.callback_query(AdminSettingsFlow.main_menu, F.data == "settings:edit_boa")
@admin_callback_required
async def cb_edit_boa(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminSettingsFlow.editing_boa)
    await callback.message.edit_text(  # type: ignore[union-attr]
        "🏦 *Update BoA Account Number*\n\n"
        "Enter the new Bank of Abyssinia account number (10–16 digits):",
        reply_markup=kb_back_to_settings(),
        parse_mode="Markdown",
    )
    await callback.answer()


@router.message(AdminSettingsFlow.editing_boa)
@admin_required
async def msg_boa_input(message: Message, state: FSMContext):
    value = (message.text or "").strip()

    if not _valid_account(value):
        await message.answer(
            "⚠️ Invalid account number. Must be 10–16 digits with no spaces.\n\nTry again:",
            reply_markup=kb_back_to_settings(),
        )
        return

    await set_setting("boa_account", value)
    await state.clear()

    settings = await get_all_settings()
    await message.answer(f"✅ BoA account updated to `{value}`.", parse_mode="Markdown")
    await message.answer(
        "⚙️ *Payment Settings*",
        reply_markup=kb_settings_menu(settings),
        parse_mode="Markdown",
    )
    await state.set_state(AdminSettingsFlow.main_menu)
