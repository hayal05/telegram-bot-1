"""
handlers/admin_products.py — FSM flow to add a new product via the admin panel.
"""
from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

import aiosqlite
from database import DB_PATH
from keyboards.keyboards import kb_admin_main
from states.states import AdminProductFlow
from utils.helpers import admin_callback_required, admin_required

router = Router()


def kb_category_picker() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📚 Book",  callback_data="newprod_cat:book")
    builder.button(text="🎬 Movie", callback_data="newprod_cat:movie")
    builder.button(text="🎵 Music", callback_data="newprod_cat:music")
    builder.adjust(3)
    return builder.as_markup()


# ─── Start: enter title ───────────────────────────────────────────────────────
@router.callback_query(F.data == "admin:add_product")
@admin_callback_required
async def cb_add_product_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminProductFlow.title)
    await callback.message.edit_text(  # type: ignore[union-attr]
        "➕ *Add New Product*\n\nStep 1/4 — Enter the product *title*:",
        parse_mode="Markdown",
    )
    await callback.answer()


# ─── Step 1: title ───────────────────────────────────────────────────────────
@router.message(AdminProductFlow.title)
@admin_required
async def msg_product_title(message: Message, state: FSMContext):
    await state.update_data(title=(message.text or "").strip())
    await state.set_state(AdminProductFlow.category)
    await message.answer(
        "Step 2/4 — Choose the *category*:",
        reply_markup=kb_category_picker(),
        parse_mode="Markdown",
    )


# ─── Step 2: category (callback) ─────────────────────────────────────────────
@router.callback_query(AdminProductFlow.category, F.data.startswith("newprod_cat:"))
@admin_callback_required
async def cb_product_category(callback: CallbackQuery, state: FSMContext):
    category = callback.data.split(":")[1]  # type: ignore[union-attr]
    await state.update_data(category=category)
    await state.set_state(AdminProductFlow.price)
    await callback.message.edit_text(  # type: ignore[union-attr]
        f"Category: *{category}*\n\nStep 3/4 — Enter the *price* in ETB (numbers only):",
        parse_mode="Markdown",
    )
    await callback.answer()


# ─── Step 3: price ───────────────────────────────────────────────────────────
@router.message(AdminProductFlow.price)
@admin_required
async def msg_product_price(message: Message, state: FSMContext):
    raw = (message.text or "").strip()
    try:
        price = float(raw)
        if price <= 0:
            raise ValueError
    except ValueError:
        await message.answer("⚠️ Please enter a valid positive number (e.g. 150 or 49.99):")
        return

    await state.update_data(price=price)
    await state.set_state(AdminProductFlow.drive_link)
    await message.answer("Step 4/4 — Paste the *Google Drive link* for this product:")


# ─── Step 4: drive link + save ───────────────────────────────────────────────
@router.message(AdminProductFlow.drive_link)
@admin_required
async def msg_product_drive_link(message: Message, state: FSMContext):
    link = (message.text or "").strip()
    if not link.startswith("https://"):
        await message.answer("⚠️ Please provide a valid HTTPS link:")
        return

    data = await state.get_data()
    await state.clear()

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO products (title, category, price, drive_link) VALUES (?, ?, ?, ?)",
            (data["title"], data["category"], data["price"], link),
        )
        await db.commit()

    await message.answer(
        f"✅ *Product added successfully!*\n\n"
        f"📦 {data['title']}\n"
        f"🏷️ {data['category']} · {data['price']:.2f} ETB",
        reply_markup=kb_admin_main(),
        parse_mode="Markdown",
    )
