# 🇪🇹 Ethiopian Digital Store Bot

A Telegram bot for selling Books, Movies, and Music via Google Drive links,
with CBE, BoA, and Telebirr payment support and a full admin panel.

## Project Structure

```
ethiopian_store_bot/
├── main.py                        # Entry point — bot init & polling
├── database.py                    # Async SQLite schema + all CRUD helpers
├── requirements.txt
├── .env.example
│
├── states/
│   └── states.py                  # FSM state groups (Purchase, AdminSettings, AdminProduct)
│
├── keyboards/
│   └── keyboards.py               # All InlineKeyboardMarkup builders
│
├── utils/
│   └── helpers.py                 # Code generator, admin guard, text formatters
│
└── handlers/
    ├── purchase.py                # User journey: category→product→payment→proof
    ├── admin_verification.py      # Admin queue: view/approve/reject transactions
    ├── admin_settings.py          # FSM: edit Telebirr / CBE / BoA live
    └── admin_products.py          # FSM: add new products
```

## Quick Start

```bash
# 1. Clone and enter directory
cd ethiopian_store_bot

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env — add your BOT_TOKEN

# 5. Run
python main.py
```

## First-Time Admin Setup

After starting the bot, seed your admin Telegram ID directly in SQLite:

```bash
sqlite3 store.db "UPDATE system_settings SET value='YOUR_TELEGRAM_ID' WHERE key='admin_ids';"
```

Then use `/admin` in Telegram to access the control panel.

---

## Database Schema

### `products`
| Column | Type | Notes |
|---|---|---|
| id | INTEGER PK | Auto-increment |
| title | TEXT | Product name |
| category | TEXT | `book` / `movie` / `music` |
| price | REAL | In ETB |
| drive_link | TEXT | Google Drive share URL |
| is_active | INTEGER | Soft delete (1=active) |

### `orders`
| Column | Type | Notes |
|---|---|---|
| id | INTEGER PK | |
| user_id | INTEGER | Telegram user ID |
| product_id | INTEGER FK | → products |
| status | TEXT | `pending` / `verified` / `rejected` |
| special_code | TEXT UNIQUE | e.g. `CBE-7X29` |
| created_at | TEXT | UTC datetime |

### `transactions`
| Column | Type | Notes |
|---|---|---|
| id | INTEGER PK | |
| order_id | INTEGER FK | → orders |
| payment_method | TEXT | `cbe` / `boa` / `telebirr` |
| transaction_reference | TEXT **UNIQUE** | Prevents double-submission |
| payee_name | TEXT | Optional |
| phone_number | TEXT | Optional |
| amount | REAL | Optional, from user |
| screenshot_path | TEXT | Local file path |
| verified_at | TEXT | Set on approval |

### `system_settings`
| key | value |
|---|---|
| `telebirr_phone` | e.g. `0911234567` |
| `cbe_account` | e.g. `1000123456789` |
| `boa_account` | e.g. `2000987654321` |
| `admin_ids` | comma-separated Telegram IDs |
| `bot_username` | Your bot's @username |

---

## User Flow

```
/start
  └─ Choose category (Books / Movies / Music)
       └─ Choose product
            └─ Choose payment (CBE / BoA / Telebirr)
                 └─ Bot fetches live account from DB
                      └─ Bot generates special code (e.g. CBE-7X29)
                           └─ User pays → sends reference OR screenshot
                                └─ Pending in admin queue
```

## Admin Flow

```
/admin
  ├─ 📋 Pending Transactions
  │     └─ Select transaction → view details / screenshot
  │           ├─ ✅ Approve → sends Drive link to buyer instantly
  │           └─ ❌ Reject  → notifies buyer
  │
  ├─ ⚙️ Payment Settings  (FSM)
  │     ├─ Edit Telebirr number  → validates Ethiopian format → saves to DB
  │     ├─ Edit CBE account      → validates 10-16 digits   → saves to DB
  │     └─ Edit BoA account      → validates 10-16 digits   → saves to DB
  │
  └─ ➕ Add Product (FSM)
        └─ title → category → price → drive_link → saved to products table
```

## Security Notes

- **Admin guard**: Every admin handler checks `system_settings.admin_ids` on every call — no hardcoded IDs.
- **Unique transaction reference**: The `UNIQUE` constraint on `transaction_reference` prevents users from reusing the same reference across multiple orders.
- **Input validation**: Phone numbers and account numbers are validated with regex before being written to the database.
- **FSM state isolation**: Each admin action uses a dedicated FSM state so commands can't be accidentally triggered mid-flow.

## Production Recommendations

- Replace `MemoryStorage` with `RedisStorage` (aiogram ships with it) for persistence across restarts.
- Move `DB_PATH` to a volume-mounted path in Docker.
- Add a middleware to rate-limit the `PurchaseFlow` states per user.
- Store screenshots in object storage (e.g. MinIO / S3) rather than local disk.
