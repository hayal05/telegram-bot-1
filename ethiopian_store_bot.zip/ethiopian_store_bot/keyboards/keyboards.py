"""
keyboards/keyboards.py — All InlineKeyboardMarkup builders for the bot.
"""
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


# ─────────────────────────────────────────────
#  User-facing keyboards
# ─────────────────────────────────────────────
def kb_categories() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📚 Books",  callback_data="cat:book")
    builder.button(text="🎬 Movies", callback_data="cat:movie")
    builder.button(text="🎵 Music",  callback_data="cat:music")
    builder.adjust(1)
    return builder.as_markup()


def kb_products(products: list[dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for p in products:
        builder.button(
            text=f"{p['title']} — {p['price']:.0f} ETB",
            callback_data=f"product:{p['id']}",
        )
    builder.button(text="⬅️ Back", callback_data="back:categories")
    builder.adjust(1)
    return builder.as_markup()


def kb_payment_methods() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🏦 CBE",      callback_data="pay:cbe")
    builder.button(text="🏦 BoA",      callback_data="pay:boa")
    builder.button(text="📱 Telebirr", callback_data="pay:telebirr")
    builder.button(text="⬅️ Back",     callback_data="back:products")
    builder.adjust(2, 1, 1)
    return builder.as_markup()


def kb_cancel_purchase() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="❌ Cancel Order", callback_data="purchase:cancel")
    return builder.as_markup()


# ─────────────────────────────────────────────
#  Admin: verification queue
# ─────────────────────────────────────────────
def kb_pending_list(transactions: list[dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for txn in transactions:
        label = (
            f"#{txn['id']} · {txn['product_title']} · "
            f"{txn['payment_method'].upper()} · {txn['special_code']}"
        )
        builder.button(text=label, callback_data=f"admin_review:{txn['id']}")
    builder.button(text="🔄 Refresh", callback_data="admin:queue")
    builder.adjust(1)
    return builder.as_markup()


def kb_verify_reject(txn_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Approve",    callback_data=f"admin_approve:{txn_id}")
    builder.button(text="❌ Reject",     callback_data=f"admin_reject:{txn_id}")
    builder.button(text="⬅️ Back",       callback_data="admin:queue")
    builder.adjust(2, 1)
    return builder.as_markup()


# ─────────────────────────────────────────────
#  Admin: settings panel
# ─────────────────────────────────────────────
def kb_admin_main() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📋 Pending Transactions",      callback_data="admin:queue")
    builder.button(text="⚙️ Payment Settings",          callback_data="admin:settings")
    builder.button(text="➕ Add Product",               callback_data="admin:add_product")
    builder.adjust(1)
    return builder.as_markup()


def kb_settings_menu(settings: dict) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(
        text=f"📱 Telebirr: {settings.get('telebirr_phone', '—')}",
        callback_data="settings:edit_telebirr",
    )
    builder.button(
        text=f"🏦 CBE: {settings.get('cbe_account', '—')}",
        callback_data="settings:edit_cbe",
    )
    builder.button(
        text=f"🏦 BoA: {settings.get('boa_account', '—')}",
        callback_data="settings:edit_boa",
    )
    builder.button(text="⬅️ Back to Admin Menu", callback_data="admin:main")
    builder.adjust(1)
    return builder.as_markup()


def kb_back_to_settings() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="⬅️ Cancel", callback_data="admin:settings")
    return builder.as_markup()
