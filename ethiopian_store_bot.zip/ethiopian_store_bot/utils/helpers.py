"""
utils/helpers.py — Shared utilities: code generation, admin guard, text formatters.
"""
import random
import string
from functools import wraps
from typing import Callable

from aiogram.types import Message, CallbackQuery
from database import get_setting


# ─────────────────────────────────────────────
#  Special Code Generator
# ─────────────────────────────────────────────
def generate_special_code(prefix: str = "TXN") -> str:
    """
    Generates a short, human-readable alphanumeric code, e.g. CBE-7X29.
    Uppercase letters + digits, excluding confusable chars (0, O, I, 1).
    """
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    suffix = "".join(random.choices(alphabet, k=4))
    return f"{prefix.upper()}-{suffix}"


# ─────────────────────────────────────────────
#  Admin Guard
# ─────────────────────────────────────────────
async def is_admin(user_id: int) -> bool:
    raw = await get_setting("admin_ids") or ""
    admin_ids = [int(x.strip()) for x in raw.split(",") if x.strip().isdigit()]
    return user_id in admin_ids


def admin_required(handler: Callable):
    """Decorator for Message handlers — rejects non-admins silently."""
    @wraps(handler)
    async def wrapper(message: Message, *args, **kwargs):
        if not await is_admin(message.from_user.id):  # type: ignore[union-attr]
            await message.answer("⛔ You are not authorised to use this command.")
            return
        return await handler(message, *args, **kwargs)
    return wrapper


def admin_callback_required(handler: Callable):
    """Decorator for CallbackQuery handlers — rejects non-admins silently."""
    @wraps(handler)
    async def wrapper(callback: CallbackQuery, *args, **kwargs):
        if not await is_admin(callback.from_user.id):  # type: ignore[union-attr]
            await callback.answer("⛔ Not authorised.", show_alert=True)
            return
        return await handler(callback, *args, **kwargs)
    return wrapper


# ─────────────────────────────────────────────
#  Text Formatters
# ─────────────────────────────────────────────
PAYMENT_METHOD_LABELS = {
    "cbe":      "CBE (Commercial Bank of Ethiopia)",
    "boa":      "BoA (Bank of Abyssinia)",
    "telebirr": "Telebirr",
}

CATEGORY_EMOJI = {
    "book":  "📚",
    "movie": "🎬",
    "music": "🎵",
}


def fmt_product(p: dict) -> str:
    emoji = CATEGORY_EMOJI.get(p["category"], "🛍️")
    return f"{emoji} *{p['title']}*\n💰 {p['price']:.2f} ETB"


def fmt_payment_instruction(
    method: str,
    account: str,
    amount: float,
    special_code: str,
) -> str:
    label = PAYMENT_METHOD_LABELS.get(method, method.upper())
    if method == "telebirr":
        account_line = f"📱 Telebirr number: *{account}*"
    else:
        account_line = f"🏦 Account number: *{account}*"

    return (
        f"✅ *Order confirmed!*\n\n"
        f"Please transfer *{amount:.2f} ETB* via {label}.\n\n"
        f"{account_line}\n\n"
        f"⚠️ You *MUST* include this exact code in the "
        f"*Reason / Remark* field:\n\n"
        f"```\n{special_code}\n```\n\n"
        f"After transferring, please reply with:\n"
        f"• Your *transaction reference number*, OR\n"
        f"• A *screenshot* of your receipt.\n\n"
        f"Your order will be verified within a few minutes."
    )
