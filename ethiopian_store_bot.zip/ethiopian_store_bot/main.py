"""
main.py — Bot entry point.
Initialises the database, registers all routers, and starts polling.
"""
import asyncio
import logging
import os

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from database import init_db
from handlers import purchase, admin_verification, admin_settings, admin_products

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


async def main() -> None:
    token = os.environ.get("BOT_TOKEN")
    if not token:
        raise RuntimeError("BOT_TOKEN environment variable is not set.")

    # Initialise DB schema
    await init_db()
    logger.info("Database ready.")

    bot = Bot(
        token=token,
        default=DefaultBotProperties(parse_mode=ParseMode.MARKDOWN),
    )

    # Use MemoryStorage for FSM — swap for RedisStorage in production
    dp = Dispatcher(storage=MemoryStorage())

    # ── Register routers in priority order ──────────────────────────────────
    # Admin settings must come before purchase so FSM states don't clash
    dp.include_router(admin_settings.router)
    dp.include_router(admin_verification.router)
    dp.include_router(admin_products.router)
    dp.include_router(purchase.router)

    logger.info("Starting bot polling…")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
